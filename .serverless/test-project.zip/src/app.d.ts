import { NestFastifyApplication } from '@nestjs/platform-fastify';
export declare function bootstrap(): Promise<NestFastifyApplication>;
