import { ConfigService as NestConfigService } from '@nestjs/config';
export declare class AwsConfigService {
    private readonly nestConfigService;
    constructor(nestConfigService: NestConfigService);
    get awsAccessKeyId(): string;
    get awsSecretAccessKey(): string;
    get awsRegion(): string;
}
