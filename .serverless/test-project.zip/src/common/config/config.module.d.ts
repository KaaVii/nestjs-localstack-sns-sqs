export declare class Settings {
}
