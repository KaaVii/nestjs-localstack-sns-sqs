import { LoggerModuleAsyncParams } from 'nestjs-pino';
declare const loggerConfig: LoggerModuleAsyncParams;
export default loggerConfig;
