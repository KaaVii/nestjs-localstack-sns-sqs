import { DynamoDbService } from './dynamodb.service';
export declare class DynamoDbController {
    private readonly dynamoDbService;
    constructor(dynamoDbService: DynamoDbService);
    createItem(tableName: string, item: Record<string, any>): Promise<void>;
    getItem(tableName: string, id: string): Promise<any>;
    updateItem(tableName: string, id: string, updateData: Record<string, any>): Promise<void>;
    deleteItem(tableName: string, id: string): Promise<void>;
    getAllItems(tableName: string): Promise<any[]>;
}
