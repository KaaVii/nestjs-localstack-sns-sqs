"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDbController = void 0;
const common_1 = require("@nestjs/common");
const dynamodb_service_1 = require("./dynamodb.service");
let DynamoDbController = class DynamoDbController {
    constructor(dynamoDbService) {
        this.dynamoDbService = dynamoDbService;
    }
    async createItem(tableName, item) {
        try {
            await this.dynamoDbService.createItem(tableName, item);
        }
        catch (error) {
            throw new common_1.BadRequestException('Failed to create item in DynamoDB.');
        }
    }
    async getItem(tableName, id) {
        try {
            const key = { ID: id };
            const item = await this.dynamoDbService.getItem(tableName, key);
            if (!item) {
                throw new common_1.NotFoundException('Item not found in DynamoDB.');
            }
            return item;
        }
        catch (error) {
            throw new common_1.BadRequestException('Failed to retrieve item from DynamoDB.');
        }
    }
    async updateItem(tableName, id, updateData) {
        try {
            const key = { ID: id };
            const updateExpression = 'SET ' + Object.keys(updateData).map(key => `#${key} = :${key}`).join(', ');
            const expressionAttributeValues = Object.entries(updateData).reduce((acc, [key, value]) => {
                acc[`:${key}`] = value;
                return acc;
            }, {});
            await this.dynamoDbService.updateItem(tableName, key, updateExpression, expressionAttributeValues);
        }
        catch (error) {
            throw new common_1.BadRequestException('Failed to update item in DynamoDB.');
        }
    }
    async deleteItem(tableName, id) {
        try {
            const key = { ID: id };
            await this.dynamoDbService.deleteItem(tableName, key);
        }
        catch (error) {
            throw new common_1.BadRequestException('Failed to delete item from DynamoDB.');
        }
    }
    async getAllItems(tableName) {
        try {
            const items = await this.dynamoDbService.getAllItems(tableName);
            if (!items || items.length === 0) {
                throw new common_1.NotFoundException('No items found in DynamoDB.');
            }
            return items;
        }
        catch (error) {
            console.log(error);
            throw new common_1.BadRequestException('Failed to retrieve items from DynamoDB.');
        }
    }
};
exports.DynamoDbController = DynamoDbController;
__decorate([
    (0, common_1.Post)(':tableName'),
    __param(0, (0, common_1.Param)('tableName')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], DynamoDbController.prototype, "createItem", null);
__decorate([
    (0, common_1.Get)(':tableName/:id'),
    __param(0, (0, common_1.Param)('tableName')),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], DynamoDbController.prototype, "getItem", null);
__decorate([
    (0, common_1.Put)(':tableName/:id'),
    __param(0, (0, common_1.Param)('tableName')),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], DynamoDbController.prototype, "updateItem", null);
__decorate([
    (0, common_1.Delete)(':tableName/:id'),
    __param(0, (0, common_1.Param)('tableName')),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], DynamoDbController.prototype, "deleteItem", null);
__decorate([
    (0, common_1.Get)(':tableName'),
    __param(0, (0, common_1.Param)('tableName')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], DynamoDbController.prototype, "getAllItems", null);
exports.DynamoDbController = DynamoDbController = __decorate([
    (0, common_1.Controller)('dynamodb'),
    __metadata("design:paramtypes", [dynamodb_service_1.DynamoDbService])
], DynamoDbController);
//# sourceMappingURL=dynamodb.controller.js.map