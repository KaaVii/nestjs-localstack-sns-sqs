export declare class DynamoDbModule {
}
