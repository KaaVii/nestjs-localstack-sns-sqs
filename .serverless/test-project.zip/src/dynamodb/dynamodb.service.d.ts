export declare class DynamoDbService {
    private readonly dynamoDb;
    private readonly logger;
    constructor();
    createItem(tableName: string, item: Record<string, any>): Promise<void>;
    getItem(tableName: string, key: Record<string, any>): Promise<any | null>;
    updateItem(tableName: string, key: Record<string, any>, updateExpression: string, expressionAttributeValues: Record<string, any>): Promise<void>;
    deleteItem(tableName: string, key: Record<string, any>): Promise<void>;
    getAllItems(tableName: string): Promise<any[]>;
}
