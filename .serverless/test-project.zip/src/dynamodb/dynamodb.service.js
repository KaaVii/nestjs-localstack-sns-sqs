"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var DynamoDbService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDbService = void 0;
const common_1 = require("@nestjs/common");
const AWS = require("aws-sdk");
let DynamoDbService = DynamoDbService_1 = class DynamoDbService {
    constructor() {
        this.logger = new common_1.Logger(DynamoDbService_1.name);
        console.log('Initializing DynamoDB service...');
        this.dynamoDb = new AWS.DynamoDB({
            endpoint: process.env.AWS_ENDPOINT_URL,
            accessKeyId: process.env.AWS_ACCESS_KEY_ID,
            secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
            region: process.env.AWS_DEFAULT_REGION
        });
    }
    async createItem(tableName, item) {
        const params = {
            TableName: tableName,
            Item: AWS.DynamoDB.Converter.marshall(item),
        };
        try {
            this.logger.log(`Creating item in DynamoDB for table ${tableName}`);
            await this.dynamoDb.putItem(params).promise();
            this.logger.log(`Item created successfully.`);
        }
        catch (error) {
            this.logger.error(`Error creating item in DynamoDB: ${error.message}`);
            throw new InternalServerErrorException('Failed to create item in DynamoDB.');
        }
    }
    async getItem(tableName, key) {
        const params = {
            TableName: tableName,
            Key: AWS.DynamoDB.Converter.marshall(key),
        };
        const response = await this.dynamoDb.getItem(params).promise();
        return response.Item ? AWS.DynamoDB.Converter.unmarshall(response.Item) : null;
    }
    async updateItem(tableName, key, updateExpression, expressionAttributeValues) {
        const params = {
            TableName: tableName,
            Key: AWS.DynamoDB.Converter.marshall(key),
            UpdateExpression: updateExpression,
            ExpressionAttributeValues: AWS.DynamoDB.Converter.marshall(expressionAttributeValues),
        };
        await this.dynamoDb.updateItem(params).promise();
    }
    async deleteItem(tableName, key) {
        const params = {
            TableName: tableName,
            Key: AWS.DynamoDB.Converter.marshall(key),
        };
        await this.dynamoDb.deleteItem(params).promise();
    }
    async getAllItems(tableName) {
        const params = {
            TableName: tableName,
        };
        console.log('Scanning DynamoDB table ' + tableName + '...');
        const response = await this.dynamoDb.scan(params).promise();
        if (response.Items && response.Items.length > 0) {
            return response.Items.map((item) => AWS.DynamoDB.Converter.unmarshall(item));
        }
        else {
            return [];
        }
    }
};
exports.DynamoDbService = DynamoDbService;
exports.DynamoDbService = DynamoDbService = DynamoDbService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], DynamoDbService);
//# sourceMappingURL=dynamodb.service.js.map