"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const awsLambdaFastify = require("@fastify/aws-lambda");
const app_1 = require("./app");
const dynamodb_service_1 = require("./dynamodb/dynamodb.service");
let server;
let proxy;
const handler = async (event, context) => {
    var _a, _b, _c;
    if (!server) {
        const app = await (0, app_1.bootstrap)();
        server = (_a = app.getHttpAdapter()) === null || _a === void 0 ? void 0 : _a.getInstance();
        proxy = awsLambdaFastify(server);
    }
    if ((_c = (_b = event === null || event === void 0 ? void 0 : event.Records) === null || _b === void 0 ? void 0 : _b[0]) === null || _c === void 0 ? void 0 : _c.Sns) {
        const snsMessage = JSON.parse(event.Records[0].Sns.Message);
        console.log('Received SNS message:', snsMessage);
        const dynamoDBService = new dynamodb_service_1.DynamoDbService();
        const tableName = 'YourDynamoDBTableName';
        try {
            await dynamoDBService.createItem(tableName, snsMessage);
            console.log('Stored SNS message in DynamoDB successfully.');
        }
        catch (error) {
            console.error('Error storing SNS message in DynamoDB:', error);
        }
    }
    return proxy(event, context);
};
exports.handler = handler;
//# sourceMappingURL=lambda.js.map