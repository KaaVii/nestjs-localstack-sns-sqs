export declare class S3Module {
}
