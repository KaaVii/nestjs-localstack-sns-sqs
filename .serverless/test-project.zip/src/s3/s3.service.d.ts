export declare class S3Service {
}
