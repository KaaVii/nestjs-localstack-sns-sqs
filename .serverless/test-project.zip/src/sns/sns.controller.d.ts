import { SnsService } from './sns.service';
export declare class SnsController {
    private readonly snsService;
    constructor(snsService: SnsService);
    snsArn: string;
    handleSnsWebhook(snsMessage: any): Promise<void>;
    publishSnsMessage(body: {
        message: string;
    }): Promise<string>;
}
