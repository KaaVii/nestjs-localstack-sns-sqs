export declare class SnsModule {
}
