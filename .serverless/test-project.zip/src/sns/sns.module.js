"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SnsModule = void 0;
const common_1 = require("@nestjs/common");
const sns_service_1 = require("./sns.service");
const sns_controller_1 = require("./sns.controller");
const sns_subscription_service_1 = require("./sns.subscription.service");
let SnsModule = class SnsModule {
};
exports.SnsModule = SnsModule;
exports.SnsModule = SnsModule = __decorate([
    (0, common_1.Module)({
        providers: [sns_service_1.SnsService, sns_subscription_service_1.SnsSubscriptionService],
        exports: [sns_service_1.SnsService],
        controllers: [sns_controller_1.SnsController]
    })
], SnsModule);
//# sourceMappingURL=sns.module.js.map