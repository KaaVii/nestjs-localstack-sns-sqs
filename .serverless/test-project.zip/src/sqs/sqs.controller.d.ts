import { SqsService } from './sqs.service';
export declare class SqsController {
    private readonly sqsService;
    constructor(sqsService: SqsService);
    queueUrl: string;
    sendSqsMessage(body: {
        message: string;
    }): Promise<string>;
    receiveSqsMessage(): Promise<AWS.SQS.Message[]>;
}
