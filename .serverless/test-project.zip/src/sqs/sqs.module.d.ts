export declare class SqsModule {
}
