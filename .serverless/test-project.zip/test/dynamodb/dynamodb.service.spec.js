"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const testing_1 = require("@nestjs/testing");
const dynamodb_service_1 = require("../../src/dynamodb/dynamodb.service");
describe('DynamoDbService', () => {
    let service;
    beforeEach(async () => {
        const module = await testing_1.Test.createTestingModule({
            providers: [dynamodb_service_1.DynamoDbService],
        }).compile();
        service = module.get(dynamodb_service_1.DynamoDbService);
    });
    it('should be defined', () => {
        expect(service).toBeDefined();
    });
});
//# sourceMappingURL=dynamodb.service.spec.js.map