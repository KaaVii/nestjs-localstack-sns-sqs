"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const testing_1 = require("@nestjs/testing");
const sns_controller_1 = require("../../src/sns/sns.controller");
describe('SnsController', () => {
    let controller;
    beforeEach(async () => {
        const module = await testing_1.Test.createTestingModule({
            controllers: [sns_controller_1.SnsController],
        }).compile();
        controller = module.get(sns_controller_1.SnsController);
    });
    it('should be defined', () => {
        expect(controller).toBeDefined();
    });
});
//# sourceMappingURL=sns.controller.spec.js.map