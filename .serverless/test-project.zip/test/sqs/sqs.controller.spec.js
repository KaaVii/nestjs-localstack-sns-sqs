"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const testing_1 = require("@nestjs/testing");
const sqs_controller_1 = require("../../src/sqs/sqs.controller");
describe('SqsController', () => {
    let controller;
    beforeEach(async () => {
        const module = await testing_1.Test.createTestingModule({
            controllers: [sqs_controller_1.SqsController],
        }).compile();
        controller = module.get(sqs_controller_1.SqsController);
    });
    it('should be defined', () => {
        expect(controller).toBeDefined();
    });
});
//# sourceMappingURL=sqs.controller.spec.js.map